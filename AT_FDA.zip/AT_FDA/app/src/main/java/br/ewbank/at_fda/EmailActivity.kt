package br.ewbank.at_fda

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_email.*

class EmailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_email)

        btnEnviarEmail.setOnClickListener {
            val destinatario = "leonardo.ewbank@al.infnet.edu.br"
            val msg = editTextEmail.text.toString().trim()
            val assunto = editTextAssunto.text.toString().trim()

            sendEmail(destinatario,assunto,msg)

        }

    }

    private fun sendEmail(destinatario: String, assunto: String, msg: String) {

        val mIntent = Intent(Intent.ACTION_SEND)
        mIntent.data = Uri.parse("mailto:")
        mIntent.type = "text/plain"

        mIntent.putExtra(Intent.EXTRA_EMAIL,arrayOf(destinatario))
        mIntent.putExtra(Intent.EXTRA_SUBJECT,assunto)
        mIntent.putExtra(Intent.EXTRA_TEXT,msg)

        try {
            startActivity(Intent.createChooser(mIntent,"Escolha o email"))
        }
        catch (e:Exception){
            //se algo der errado
            Toast.makeText(this,e.message,Toast.LENGTH_LONG).show()
        }

    }
}