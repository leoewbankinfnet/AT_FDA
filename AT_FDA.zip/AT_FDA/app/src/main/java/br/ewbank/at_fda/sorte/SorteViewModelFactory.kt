package br.ewbank.at_fda.sorte

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

@Suppress("UNCHECKED_CAST")
class SorteViewModelFactory():ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(SorteViewModel::class.java))
            return SorteViewModel() as T
        throw IllegalArgumentException("Argumento invalido")
    }


}