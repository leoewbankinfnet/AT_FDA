package br.ewbank.at_fda.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import br.ewbank.at_fda.R
import kotlinx.android.synthetic.main.home_fragment.*

class HomeFragment : Fragment() {



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.home_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        btnHomeCreditos.setOnClickListener {
            findNavController().navigate(R.id.creditosFragment)
        }
        btnHomeJogar.setOnClickListener {
            findNavController().navigate(R.id.sorteFragment)
        }

    }

}