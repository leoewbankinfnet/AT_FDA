package br.ewbank.at_fda.creditos

import androidx.lifecycle.ViewModel

class CreditosViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}