package br.ewbank.at_fda.sorte

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlin.random.Random

class SorteViewModel : ViewModel() {

    var valorDado = MutableLiveData<Int>()

    init {
        valorDado.value = 1
    }

    fun rodarDado(){
        valorDado.value  = Random.nextInt(1,7)
    }

}