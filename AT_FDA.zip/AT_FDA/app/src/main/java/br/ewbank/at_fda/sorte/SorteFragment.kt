package br.ewbank.at_fda.sorte

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import br.ewbank.at_fda.R
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.sorte_fragment.*

class SorteFragment : Fragment() {


    private lateinit var sorteViewModel: SorteViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view = inflater.inflate(R.layout.sorte_fragment, container, false)

        sorteViewModel = ViewModelProvider(this,SorteViewModelFactory()).get(SorteViewModel::class.java)

        sorteViewModel.valorDado.observe(viewLifecycleOwner){
            TextViewDado.text = sorteViewModel.valorDado.value.toString()
        }

        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)



        TextViewAjuda.setOnClickListener {
            showSnackbar("Digite um numero de 1 a 6 e jogue o dado")
        }

        btnRodarDado.setOnClickListener {

            if(editTextNumeroJogador.text.toString().isNotBlank() &&
                editTextNumeroJogador.text.toString().isNotEmpty() &&
                editTextNumeroJogador.text.toString().toInt() in 1..6 ) {
                    val num = editTextNumeroJogador.text.toString().toInt()
                    jogar(num)
            }
            else
                showSnackbar("Digite um numero entre 1 e 6")

            hideKeyboard()
            //TextViewDado.text=sorteViewModel.valorDado.value.toString()

        }
    }

    private fun jogar(num:Int?) {

        sorteViewModel.rodarDado()

        if(TextViewDado.text.toString().compareTo(num.toString())==0)
            showSnackbar("Voce ganhou")
        else
            showSnackbar("Voce perdeu")

    }


    private fun showSnackbar(msg:String) {
        Snackbar.make(sorte_layout_root, msg, Snackbar.LENGTH_LONG)
            .show()
    }
    fun Fragment.hideKeyboard() {
        view?.let { activity?.hideKeyboard(it) }
    }

    fun Activity.hideKeyboard() {
        hideKeyboard(currentFocus ?: View(this))
    }

    fun Context.hideKeyboard(view: View) {
        val inputMethodManager = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
    }

}