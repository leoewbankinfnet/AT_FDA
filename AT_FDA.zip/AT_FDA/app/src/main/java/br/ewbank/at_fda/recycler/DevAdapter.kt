package br.ewbank.at_fda.recycler

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import br.ewbank.at_fda.R

import kotlinx.android.synthetic.main.dev_list.*

class DevAdapter:RecyclerView.Adapter<DevAdapter.DevViewholder>() {

    val listaNome= listOf("Nome: Leonardo Ewbank "," Email:leonardo.ewbank@al.infnet.edu.br","Curso: Eng da Computação")

    override fun getItemCount() = listaNome.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DevViewholder {
        val card = LayoutInflater.from(parent.context).inflate(R.layout.dev_list,parent,false)
        return DevViewholder(card)
    }

    override fun onBindViewHolder(holder: DevViewholder, position: Int) {
        holder.nomeTextView.text=listaNome[position]
    }


    class DevViewholder(itemView:View):RecyclerView.ViewHolder(itemView){
        val nomeTextView: TextView = itemView.findViewById(R.id.nome_text_view)
    }
}