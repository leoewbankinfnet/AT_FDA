package br.ewbank.at_fda.creditos

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import br.ewbank.at_fda.R
import kotlinx.android.synthetic.main.creditos_fragment.*

class CreditosFragment : Fragment() {


    private lateinit var viewModel: CreditosViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view = inflater.inflate(R.layout.creditos_fragment, container, false)

        viewModel = ViewModelProvider(this).get(CreditosViewModel::class.java)


        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        btnEmail.setOnClickListener{
            findNavController().navigate(R.id.emailActivity)
        }
    }

}