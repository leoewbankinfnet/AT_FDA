package br.ewbank.at_fda.creditos

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import br.ewbank.at_fda.R
import br.ewbank.at_fda.recycler.DevAdapter
import kotlinx.android.synthetic.main.creditos_fragment.*

class CreditosFragment : Fragment() {



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view = inflater.inflate(R.layout.creditos_fragment, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        configurarRecyclerView()
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        btnEmail.setOnClickListener{
            findNavController().navigate(R.id.emailActivity)
        }

    }

    private fun configurarRecyclerView(){
        lista_dev.layoutManager = LinearLayoutManager(activity)
        lista_dev.adapter = DevAdapter()
    }

}